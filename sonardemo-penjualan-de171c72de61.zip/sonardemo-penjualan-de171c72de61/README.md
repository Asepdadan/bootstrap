### Simple Retail Application Using CodeIgniter & Bootstrap v.2.x.x ###

# V.2 
- Fixed Bugs
- Added Report Menu 
- Using dynamic base_url

Credit : gilangsonar.com